<?php

// Esto es un comentario de doble barras y de una linea se hace con shift + 7

# Esto es un comentario de una linea con hashtag o sharp o numeral se hace con Shift + 3

/* Esto es un comentario de varias lineas
echo "Hola Mundo";
$variable = "variable";
O tambien denominado comentario de bloque

Atajo de teclado: Alt + Shift + A */

$variableMuyLarga = "variable <br>"; // Esto es una declaracion de variable
$VariableMuyLarga = "otra" . /*. es el operador de concatenación*/"variable<br>"; // Las variables son sensible a las mayusculas

echo $variableMuyLarga;
echo $VariableMuyLarga;
echo "hola ", "mundo", "<br>";

class Persona
{}

$p1 = new Persona;
$p2 = new PerSonA;
$p3 = new PERSONA;

function SitioWeb()
{
    echo "soydigitalmind.com <br>";
}

SitioWeb();
SiTioWeB();
SITIOWEB();
